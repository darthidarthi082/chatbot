import streamlit as st
import google.generativeai as genai

st.title("LogiSupport AI Assistant")

# Sidebar API key
api_key = st.sidebar.text_input("🔑 Google Gemini API Key", type="password")

if api_key:
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel("gemini-1.5-flash")

    st.success("✅ AI Connected")

    user_input = st.chat_input("Ask something...")

    if "messages" not in st.session_state:
        st.session_state.messages = []

    if user_input:
        st.session_state.messages.append(("user", user_input))
        response = model.generate_content(user_input)
        st.session_state.messages.append(("bot", response.text))

    for role, msg in st.session_state.messages:
        st.chat_message(role).write(msg)

else:
    st.warning("⚠️ Enter your API key in the sidebar")
"""
Logistics Customer Support Chatbot
Powered by Google Gemini API + Streamlit
Developed by: Darthi A | GenAI Internship | June 2026
"""

import streamlit as st
import google.generativeai as genai
import csv
import json
import datetime
import os
import re

PAGE_TITLE = "LogiSupport AI Chatbot"
MODEL = "gemini-1.5-flash"

# ─────────────────────────────────────────────
#  MOCK DATA
# ─────────────────────────────────────────────
MOCK_SHIPMENTS = {
    "LGX2025061201": {"status": "In Transit", "location": "Chennai Distribution Hub",
                      "updated": "12 Jun 2026, 10:32 AM", "eta": "14 Jun 2026"},
    "LGX2025061202": {"status": "Out for Delivery", "location": "Local Delivery Agent",
                      "updated": "12 Jun 2026, 09:15 AM", "eta": "Today by 6:00 PM"},
    "LGX2025061203": {"status": "Delivered", "location": "Delivered to Doorstep",
                      "updated": "11 Jun 2026, 03:45 PM", "eta": "Delivered"},
    "LGX2025061204": {"status": "Delayed", "location": "Bangalore Sorting Facility",
                      "updated": "12 Jun 2026, 06:00 AM", "eta": "16 Jun 2026"},
}

SERVICEABLE_PINCODES = {
    "607001": "Cuddalore, Tamil Nadu",
    "600001": "Chennai, Tamil Nadu",
    "110001": "Delhi",
    "400001": "Mumbai, Maharashtra",
    "560001": "Bangalore, Karnataka",
}

WAREHOUSES = {
    "chennai":   {"name": "Chennai Central Hub",   "address": "45, Nehru Street, Perambur, Chennai - 600011",    "hours": "Mon-Sat 8AM-8PM", "phone": "044-12345678"},
    "delhi":     {"name": "Delhi NCR Mega Hub",    "address": "Plot 12, Sector 5, Dwarka, New Delhi - 110075",    "hours": "24/7",            "phone": "011-87654321"},
    "bangalore": {"name": "Bangalore South Hub",   "address": "No. 8, Industrial Layout, Hosur Road, BLR-560068","hours": "Mon-Sat 8AM-8PM", "phone": "080-11223344"},
    "mumbai":    {"name": "Mumbai Logistics Park",  "address": "Unit 3, Turbhe MIDC, Navi Mumbai - 400705",       "hours": "Mon-Sat 7AM-9PM", "phone": "022-55667788"},
}

PRICING = {
    "standard": {"label": "Standard (3-5 days)", "base": 50,  "per_kg": 20},
    "express":  {"label": "Express (1-2 days)",  "base": 150, "per_kg": 50},
    "overnight":{"label": "Overnight Delivery",  "base": 300, "per_kg": 80},
}

# ─────────────────────────────────────────────
#  LOAD FAQ
# ─────────────────────────────────────────────
def load_faq(filepath="02_FAQ_Knowledge_Base.csv"):
    faqs = []
    if os.path.exists(filepath):
        with open(filepath, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                faqs.append(row)
    return faqs

def build_faq_context(faqs):
    lines = ["LOGISTICS FAQ KNOWLEDGE BASE:", ""]
    for faq in faqs:
        lines.append(f"Q: {faq['Customer Query']}")
        lines.append(f"A: {faq['Chatbot Response']}")
        lines.append("")
    return "\n".join(lines)

# ─────────────────────────────────────────────
#  TOOL HANDLERS
# ─────────────────────────────────────────────
def track_shipment(tracking_id):
    tid = tracking_id.strip().upper()
    if tid in MOCK_SHIPMENTS:
        s = MOCK_SHIPMENTS[tid]
        return (f"**Tracking ID:** {tid}\n"
                f"**Status:** {s['status']}\n"
                f"**Current Location:** {s['location']}\n"
                f"**Last Updated:** {s['updated']}\n"
                f"**Estimated Delivery:** {s['eta']}")
    return f"No shipment found for tracking ID **{tid}**. Please verify and try again."

def check_serviceability(pincode):
    pc = pincode.strip()
    if pc in SERVICEABLE_PINCODES:
        return f"✅ Pincode {pc} ({SERVICEABLE_PINCODES[pc]}) is serviceable. We offer Standard and Express delivery here."
    return f"❌ Pincode {pc} is not directly serviceable. You may drop off at our nearest facility."

def get_warehouse_info(city):
    key = city.lower().strip()
    for k, info in WAREHOUSES.items():
        if k in key or key in k:
            return (f"**{info['name']}**\n"
                    f"📍 {info['address']}\n"
                    f"🕐 {info['hours']}\n"
                    f"📞 {info['phone']}")
    return f"No warehouse found for {city}. We have facilities in Chennai, Delhi, Bangalore, and Mumbai."

def get_pricing_quote(weight_kg):
    try:
        w = float(weight_kg)
    except Exception:
        return "Please provide a valid weight in kilograms."
    lines = ["**Pricing Quote:**\n"]
    for stype, info in PRICING.items():
        cost = info["base"] + (info["per_kg"] * w)
        lines.append(f"- {info['label']}: **Rs. {cost:.0f}**")
    return "\n".join(lines)

def log_escalation(name, contact, issue):
    ref = f"ESC-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}"
    log_entry = {"ref": ref, "name": name, "contact": contact,
                 "issue": issue, "timestamp": datetime.datetime.now().isoformat()}
    log_file = "escalation_log.json"
    logs = []
    if os.path.exists(log_file):
        with open(log_file) as f:
            try: logs = json.load(f)
            except: logs = []
    logs.append(log_entry)
    with open(log_file, "w") as f:
        json.dump(logs, f, indent=2)
    return f"✅ Escalation logged (Ref: **{ref}**). Our agent will contact **{name}** on **{contact}** shortly."

# ─────────────────────────────────────────────
#  ENTITY EXTRACTION
# ─────────────────────────────────────────────
def extract_tracking_id(text):
    match = re.search(r'\bLGX\d{10}\b', text, re.IGNORECASE)
    return match.group(0).upper() if match else None

def extract_pincode(text):
    match = re.search(r'\b\d{6}\b', text)
    return match.group(0) if match else None

def extract_weight(text):
    match = re.search(r'(\d+\.?\d*)\s*(?:kg|kgs|kilogram)', text, re.IGNORECASE)
    return match.group(1) if match else None

def detect_city(text):
    for city in WAREHOUSES:
        if city in text.lower():
            return city
    return None

# ─────────────────────────────────────────────
#  SYSTEM PROMPT
# ─────────────────────────────────────────────
def build_system_prompt(faq_context):
    return f"""You are LogiSupport, a friendly and professional AI customer support assistant for a logistics company.

You help customers with:
1. Shipment tracking (tracking IDs look like LGX2025061201)
2. Delivery status and ETA updates
3. Pricing quotes (weight in kg + service type)
4. Service availability by pincode or city
5. Warehouse and pickup information
6. Damage/loss claims
7. Escalation to human agents
8. General logistics FAQs

Rules:
- Always be polite, concise, and empathetic
- If tool result data is provided in the message, use it directly in your response
- Never make up shipment statuses or tracking data
- After 2 failed attempts to resolve, offer human escalation
- End responses with a helpful follow-up question

Current date: {datetime.datetime.now().strftime("%d %B %Y")}

---
{faq_context}
---"""

# ─────────────────────────────────────────────
#  GEMINI CHAT
# ─────────────────────────────────────────────
def get_bot_response(user_message, conversation_history, faq_context, api_key):
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(
        model_name=MODEL,
        system_instruction=build_system_prompt(faq_context)
    )

    # Entity-based tool dispatch
    tracking_id = extract_tracking_id(user_message)
    pincode = extract_pincode(user_message)
    weight = extract_weight(user_message)
    city = detect_city(user_message)
    tool_result = None
    lower = user_message.lower()

    if tracking_id and any(w in lower for w in ["track","where","status","shipment","package","delivery","when"]):
        tool_result = track_shipment(tracking_id)
    elif pincode and any(w in lower for w in ["deliver","service","area","available","pincode","ship to"]):
        tool_result = check_serviceability(pincode)
    elif city and any(w in lower for w in ["warehouse","facility","pickup","drop","address","location","hub"]):
        tool_result = get_warehouse_info(city)
    elif weight and any(w in lower for w in ["price","cost","charge","rate","quote","how much"]):
        tool_result = get_pricing_quote(weight)

    # Build Gemini history
    gemini_history = []
    for msg in conversation_history:
        role = "user" if msg["role"] == "user" else "model"
        gemini_history.append({"role": role, "parts": [msg["content"]]})

    chat = model.start_chat(history=gemini_history)

    if tool_result:
        full_message = f"{user_message}\n\n[SYSTEM DATA - use this in your response]:\n{tool_result}"
    else:
        full_message = user_message

    response = chat.send_message(full_message)
    return response.text

# ─────────────────────────────────────────────
#  STREAMLIT UI
# ─────────────────────────────────────────────
def main():
    st.set_page_config(page_title=PAGE_TITLE, page_icon="📦", layout="centered")

    st.markdown("""
    <style>
    .chat-header { background: linear-gradient(135deg,#1B3A6B,#2E5EAA); color:white;
                   padding:18px 24px; border-radius:12px; margin-bottom:20px; text-align:center; }
    .chat-header h2 { margin:0; font-size:1.4rem; }
    .chat-header p  { margin:4px 0 0; font-size:0.85rem; opacity:0.85; }
    </style>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class='chat-header'>
      <h2>📦 LogiSupport AI Assistant</h2>
      <p>Shipment Tracking · Delivery Updates · Pricing · Warehouse Info · Claims</p>
    </div>
    """, unsafe_allow_html=True)

    with st.sidebar:
        st.markdown("### LogiSupport AI")
        api_key = st.text_input("🔑 Google Gemini API Key", type="password",
                                help="Get free key at aistudio.google.com")
        st.caption("Get your free key at [aistudio.google.com](https://aistudio.google.com)")
        st.markdown("---")
        st.markdown("**Quick Topics**")
        for t in ["🚚 Track Shipment","📅 Delivery ETA","💰 Pricing",
                  "📍 Service Availability","🏭 Warehouse Info","⚠️ File a Claim","👤 Talk to Agent"]:
            st.markdown(f"- {t}")
        st.markdown("---")
        if st.button("🗑️ Clear Chat"):
            st.session_state.messages = []
            st.rerun()
        st.caption("LogiSupport AI · Powered by Gemini · Darthi A")

    faqs = load_faq()
    faq_context = build_faq_context(faqs)

    if "messages" not in st.session_state:
        st.session_state.messages = []

    if not st.session_state.messages:
        greeting = ("Hello! 👋 Welcome to **LogiSupport**. I'm your AI assistant.\n\n"
                    "I can help you with:\n"
                    "- 📦 **Track a shipment** — share your Tracking ID (e.g. LGX2025061201)\n"
                    "- 🚚 **Delivery status & ETA**\n"
                    "- 💰 **Pricing & charges**\n"
                    "- 📍 **Service availability** by pincode\n"
                    "- 🏭 **Warehouse & pickup** information\n"
                    "- ⚠️ **Claims** for damaged or lost shipments\n"
                    "- 👤 **Talk to a human agent**\n\n"
                    "How can I assist you today?")
        st.session_state.messages.append({"role": "assistant", "content": greeting})

    for msg in st.session_state.messages:
        with st.chat_message(msg["role"], avatar="📦" if msg["role"] == "assistant" else "🙂"):
            st.markdown(msg["content"])

    user_input = st.chat_input("Type your message here...")

    if user_input:
        if not api_key:
            st.warning("⚠️ Please enter your Google Gemini API Key in the sidebar.")
            return

        st.session_state.messages.append({"role": "user", "content": user_input})
        with st.chat_message("user", avatar="🙂"):
            st.markdown(user_input)

        with st.chat_message("assistant", avatar="📦"):
            with st.spinner("LogiSupport is thinking..."):
                try:
                    history = st.session_state.messages[:-1]
                    reply = get_bot_response(user_input, history, faq_context, api_key)
                except Exception as e:
                    reply = f"⚠️ Error: {str(e)}\nPlease check your API key and try again."
            st.markdown(reply)

        st.session_state.messages.append({"role": "assistant", "content": reply})

if __name__ == "__main__":
    main()
